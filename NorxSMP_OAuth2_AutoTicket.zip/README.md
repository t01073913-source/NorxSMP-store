# NorxSMP OAuth2 Auto-Ticket

Flow: Website -> pilih rank -> Discord OAuth2 -> callback -> D1 -> bot polling -> private BUY RANK ticket.

Cloudflare:
- Create D1 and run `pages/schema.sql`.
- Bind D1 as `DB`.
- Variables/Secrets:
  DISCORD_CLIENT_ID
  DISCORD_CLIENT_SECRET (secret)
  DISCORD_REDIRECT_URI=https://norxsmp.xyz/api/discord/callback
  BOT_API_SECRET (secret)

Discord Developer Portal:
- OAuth2 redirect URL must exactly be `https://norxsmp.xyz/api/discord/callback`
- Scope: `identify`

Bot env:
- BOT_TOKEN (secret)
- GUILD_ID
- TICKET_API_URL=https://norxsmp.xyz/api/tickets
- TICKET_API_SECRET=same value as Cloudflare BOT_API_SECRET

Bot needs Manage Channels, View Channels, Send Messages, Read Message History.
The user must already be in the Discord server; OAuth2 identifies the exact Discord account.

Discord: https://discord.gg/USFDPb6WB
IP: norxsmp.play.hosting
