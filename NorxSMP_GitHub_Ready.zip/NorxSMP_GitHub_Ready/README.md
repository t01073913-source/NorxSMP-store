# NorxSMP Store — GitHub Ready

Struktur ini sudah siap di-upload ke repository GitHub **tanpa folder `pages/` di paling luar**.

## Struktur
- `index.html`, `style.css`, `script.js` — website store
- `functions/api/discord/` — Discord OAuth2
- `functions/api/tickets/pending.js` — API antrian ticket
- `bot/` — bot Discord Auto Ticket
- `schema.sql` — tabel D1

## Cloudflare Pages
1. Import repository ini ke Cloudflare Pages.
2. Build command: `exit 0`
3. Build output directory: `.`
4. Buat D1 database dan binding bernama `DB`.
5. Jalankan `schema.sql` di D1.
6. Tambahkan secrets/environment variables:
   - `DISCORD_CLIENT_ID`
   - `DISCORD_CLIENT_SECRET`
   - `DISCORD_REDIRECT_URI=https://norxsmp.xyz/api/discord/callback`
   - `BOT_API_SECRET`

## Discord OAuth2
Tambahkan Redirect URL:
`https://norxsmp.xyz/api/discord/callback`

## Bot Auto Ticket
Bot perlu online 24/7 dan punya permission:
- View Channels
- Send Messages
- Read Message History
- Manage Channels

Environment bot:
- `BOT_TOKEN`
- `GUILD_ID`
- `TICKET_API_URL=https://norxsmp.xyz/api/tickets`
- `TICKET_API_SECRET` (sama dengan `BOT_API_SECRET`)

Jangan pernah memasukkan Bot Token atau Client Secret ke file website/public repository.
